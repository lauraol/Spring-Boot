package br.org.generation.webmotors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebmotorsApplicationTests {

	@Test
	void contextLoads() {
	}

}
