package br.org.generation.sistemaalunos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaalunosApplicationTests {

	@Test
	void contextLoads() {
	}

}
